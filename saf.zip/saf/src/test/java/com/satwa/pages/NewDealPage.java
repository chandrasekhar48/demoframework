package com.satwa.pages;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.satwa.utils.EventUtil;
import com.satwa.utils.GlobalVariables;

public class NewDealPage extends EventUtil {
	
	private WebDriver driver;
	
	private static ThreadLocal<NewDealPage> threadLocal = new ThreadLocal<>();
	
	public static void set(NewDealPage newDealPage) {
		threadLocal.set(newDealPage);
	}
	
	public static NewDealPage get() {
		return threadLocal.get();
	}
	
	public NewDealPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}
	
	@FindBy(xpath="//button[text()='Create']")
	private WebElement btnCreate;
	
	@FindBy(xpath = "//div[text()='Create new Deal']")
	private WebElement lblCreateDealPageHeader;
	
	@FindBy(xpath="//label[text()='Title']/following-sibling::div//input[@name='title']")
	private WebElement txtDealTitleName;

	@FindBy(xpath="//label[text()='Access']/following-sibling::div//button")
	private WebElement btnAccess;
	
	@FindBy(xpath = "//div[text()='Select users allowed access']/parent::div")
	private WebElement lstUsersForAccess;

	@FindBy(xpath = "//label[text()='Amount']/..//input")
	private WebElement txtAmount;
	
	@FindBy(xpath = "//label[text()='Commission']/..//input")
	private WebElement txtCommission;
	
	@FindBy(xpath = "//div[@name='stage']/i")
	private WebElement stageDrpDwnList;
	
	@FindBy(xpath = "//div[@name='stage']/span")
	private WebElement stageDrpDwnOptions;
	
	@FindBy(xpath = "//div[@name='status']/i")
	private WebElement statusDrpDwnList;
	
	@FindBy(xpath = "//div[@name='status']/span")
	private WebElement statusDrpDwnOptions;
	
	@FindBy(xpath = "//label[text()='Next Steps']/following-sibling::textarea")
	private WebElement txtNextSteps;
	
	@FindBy(xpath = "//div[@name='type']/i")
	private WebElement typeDrpDwnList;
	
	@FindBy(xpath = "//div[@name='type']/span")
	private WebElement typeDrpDwnOptions;
	
	@FindBy(xpath = "//div[@name='source']/i")
	private WebElement sourceDrpDwnList;
	
	@FindBy(xpath = "//div[@name='source']/span")
	private WebElement sourceDrpDwnOptions;
	
	@FindBy(xpath = "//label[text()='Identifier']/..//input")
	private WebElement txtIdentifier;
	
	@FindBy(xpath = "//button[text()='Save']")
	private WebElement btnSave;
	
	
	
	public boolean navigateToCreateDealPage() {
		clickElement(btnCreate);
		return checkElementExists(lblCreateDealPageHeader);
	}
	
	public void enterDealData() {
		enterValue(txtDealTitleName, "Deal001");
		selectDealAccessStatus("Public");
		enterValue(txtAmount, "100");
		enterValue(txtCommission, "10");
		clickElement(stageDrpDwnList);
		selectValueFromList(stageDrpDwnOptions, "Qualify");
		clickElement(statusDrpDwnList);
		selectValueFromList(statusDrpDwnOptions, "Active");
		enterValue(txtNextSteps, "Hello World");
		clickElement(typeDrpDwnList);
		selectValueFromList(typeDrpDwnOptions, "Opportunity");
		clickElement(sourceDrpDwnList);
		selectValueFromList(sourceDrpDwnOptions, "Existing Customer");
		enterValue(txtIdentifier, "ID01122A");
		clickElement(btnSave);
		
		
		
		
	}

	public String getCurrentAccessLevel() {
		waitForElementToVisible(btnAccess, GlobalVariables.DEFAULT_EXPLICIT_WAIT);
		return btnAccess.getText();
	}
	private void selectDealAccessStatus(String statusToSelect) {
		waitForElementToVisible(btnAccess, GlobalVariables.DEFAULT_EXPLICIT_WAIT);
		if (!getCurrentAccessLevel().equalsIgnoreCase(statusToSelect)) {
			clickElement(btnAccess);
		}
		
		
	}


}
