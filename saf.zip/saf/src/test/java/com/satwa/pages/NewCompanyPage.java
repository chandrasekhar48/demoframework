package com.satwa.pages;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.satwa.utils.EventUtil;
import com.satwa.utils.GlobalVariables;

public class NewCompanyPage extends EventUtil{
	
	private WebDriver driver;
	
	private static ThreadLocal<NewCompanyPage> threadLocal = new ThreadLocal<>();
	
	public static void set(NewCompanyPage newCompanyPage) {
		threadLocal.set(newCompanyPage);
	}
	
	public static NewCompanyPage get() {
		return threadLocal.get();
	}
	
	
	@FindBy(xpath="//button[text()='Create']")
	private WebElement btnCreate;
	
	@FindBy(xpath = "//div[text()='Create new Company']")
	private WebElement lblCreateCompanyPageHeader;
	
	@FindBy(xpath="//label[text()='Name']/following-sibling::div//input[@name='name']")
	private WebElement txtCompanyName;

	@FindBy(xpath="//label[text()='Access']/following-sibling::div//button")
	private WebElement btnAccess;
	
	@FindBy(xpath = "//label[text()='Phone']/..//i[@class='dropdown icon']")
	private WebElement phCountriesDrpDwn  ;
	
	@FindBy(xpath = "//label[text()='Phone']/..//span")
	private WebElement txtPhCountryName;
	
	@FindBy(xpath = "//label[text()='Phone']/..//input[@name='value']")
	private WebElement txtPhNumber;
	
	@FindBy(xpath = "//label[text()='Phone']/..//input[@name='name']")
	private WebElement txtHomeWorkField;
	
	@FindBy(xpath = "(//button[@class='ui tiny basic icon button'])[2]")
	private WebElement addicon;
	
	@FindBy(xpath = "(//button[@class='ui tiny basic icon button'])[2]")
	private WebElement removeicon;
	
	@FindBy(xpath = "//label[text()='Address']/..//input[@name='address']")
	private WebElement txtaddress;
	
	@FindBy(xpath = "//label[text()='Address']/..//input[@name='city']")
	private WebElement txtcity;
	
	@FindBy(xpath="//label[text()='Address']/..//input[@name='state']")
	private WebElement txtstate;
	
	@FindBy(xpath = "//label[text()='Address']/..//input[@name='zip']")
	private WebElement txtpin;
	
	@FindBy(xpath = "//label[text()='Address']/..//i[@class='dropdown icon']")
	private WebElement adcountriesDrpDwn  ;
	
	@FindBy(xpath = "//label[text()='Address']/..//span")
	private WebElement adCountryName;
	
	@FindBy(xpath = "(//button[@class='ui tiny basic icon button'])[1]")
	private WebElement adAddIcon;
	
	@FindBy(xpath = "(//button[@class='ui tiny basic icon button'])[1]")
	private WebElement adRemoveIcon;
	
	@FindBy(xpath = "//label[text()='Tags']/..//div[@aria-expanded='true']")
	private WebElement tagSearch;
	
	
	@FindBy(xpath = "//div[@class='visible menu transition']//span")
	private WebElement textTagValue;
	
	@FindBy(xpath = "//label[text()='Social Channels']/..//i[@class='dropdown icon']")
	private WebElement lstSocialChannels;
	
	@FindBy(xpath = "//label[text()='Social Channels']/..//span")
	private WebElement socialChannelsOptions;
	
	@FindBy(xpath = "//label[text()='Social Channels']/..//input[contains(@placeholder,' profile link')]")
	private WebElement socialChannelProfileLink;
	
	@FindBy(xpath = "//label[text()='Social Channels']/..//i[@class='add icon']")
	private WebElement sclChnlAddIcon;
	
	@FindBy(xpath = "(//label[text()='Social Channels']/..//i[@class='remove icon'])[1]")
	private WebElement sclChnlRemoveIcon;
	
	public NewCompanyPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}
	
	public boolean navigateToCreateCompanyPage() {
		clickElement(btnCreate);
		return checkElementExists(lblCreateCompanyPageHeader, GlobalVariables.DEFAULT_EXPLICIT_WAIT);
	}
	
	public void enterCompanyData(Map<String, String> data) {
		enterValue(txtCompanyName, data.get("COMPANY_NAME"));
		selectCompanyAccess(data.get("ACCESS"));
		clickElement(phCountriesDrpDwn);
		selectValueFromList(txtPhCountryName, data.get("India"));
		enterValue(txtPhNumber,data.get("9999999990"));
		enterValue(txtHomeWorkField, data.get("software"));
		clickElement(addicon);
		clickElement(removeicon);
		enterValue(txtaddress, data.get("xyzstreet"));
		enterValue(txtcity, data.get("DMM"));
		enterValue(txtstate, data.get("AP"));
		enterValue(txtpin, data.get("515756"));
		clickElement(adcountriesDrpDwn);
		selectValueFromList(adCountryName, data.get("Tonga"));
		clickElement(adAddIcon);
		clickElement(adRemoveIcon);
		clickElement(tagSearch);
		enterValue(tagSearch, data.get("chandra"));
		clickElement(tagSearch);
		selectValueFromList(textTagValue, data.get("xyz"));
		clickElement(lstSocialChannels);
		selectValueFromList(socialChannelsOptions, data.get("LinkedIn"));
		enterValue(socialChannelProfileLink, data.get("profileLink"));
		clickElement(sclChnlAddIcon);
		clickElement(sclChnlRemoveIcon);
		
		
		
		
	}

	public String getCurrentAccessLevel() {
		waitForElementToVisible(btnAccess, GlobalVariables.DEFAULT_EXPLICIT_WAIT);
		return btnAccess.getText();
	}
	private void selectCompanyAccess(String accessToSelect) {
		waitForElementToVisible(btnAccess, GlobalVariables.DEFAULT_EXPLICIT_WAIT);
		if (!getCurrentAccessLevel().equalsIgnoreCase(accessToSelect)) {
			clickElement(btnAccess);
		}
		
		
	}

}
