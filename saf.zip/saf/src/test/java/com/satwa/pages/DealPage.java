package com.satwa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.satwa.utils.EventUtil;

public class DealPage  extends EventUtil {
	
	private WebDriver driver;
	
	private static ThreadLocal<DealPage> threadLocal = new ThreadLocal<>();
	
	public static void set(DealPage dealPage) {
		threadLocal.set(dealPage);
	}
	
	public static DealPage get() {
		return threadLocal.get();
	}
	
	
	public WebDriver getWebDriver() {
		return driver;
	}
	
	@FindBy(xpath="//span[text()='Deals']")
	private WebElement lnkDeal;
	
	@FindBy(xpath = "//div[starts-with(@class,'ui header') and text()='Deals']")
	private WebElement lblDealPageHeader;

	public DealPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
		
	}
	
	public boolean navigateToDealPage() {
		clickElement(lnkDeal);
		return checkElementExists(lblDealPageHeader);
		
	}


}
